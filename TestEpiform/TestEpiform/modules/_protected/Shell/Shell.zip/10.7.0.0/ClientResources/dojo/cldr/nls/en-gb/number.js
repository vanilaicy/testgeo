//>>built
define("dojo/cldr/nls/en-gb/number",{"currencyFormat":"¤#,##0.00","decimalFormat-short":"000T"});